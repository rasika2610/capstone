<?php
\Magento\Framework\component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'ITCInfotech_CustomLayouts',
    __DIR__
);