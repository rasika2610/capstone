<?php
\Magento\Framework\component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Leelas_addNewSection',
    __DIR__
);