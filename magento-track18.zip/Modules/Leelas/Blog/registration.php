<?php

\Magento\Framework\component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Leelas_Blog',
    __DIR__
);